define("epi-forms/widget/_ChoiceItemWithExtendedWidget", [// dojo
"dojo/_base/declare", "dojo/when", "dojo/_base/lang", "dojo/aspect", // epi-addons
"epi-forms/widget/_ChoiceItemWith"], function ( // dojo
declare, when, lang, aspect, // epi-addons
_ChoiceItemWith) {
  // module:
  //      epi-forms/widget/_ChoiceItemWithExtendedWidget
  // summary:
  //
  // tags:
  //      public
  return declare([_ChoiceItemWith], {
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);

      this._setupExtendedWidget(this.item);
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _updateSelectorValue: function _updateSelectorValue(
    /*String*/
    value) {
      // summary:
      //       Update value for selector
      // value: [String]
      //
      // returns: [String]
      //
      // tags:
      //      protected, abstract
      if (value === null) {
        return [value];
      }

      if (!this._selector || !this._selector.domNode) {
        return [value];
      }

      var selectorValue = this._selector.value;

      if (typeof selectorValue !== "string") {
        return [value];
      }

      this.inherited(arguments);
      return [this._selector.get("value")];
    },
    _calculateSelectorValue: function _calculateSelectorValue() {
      // summary:
      //      Reset value of the selector.
      // tags:
      //      protected
      var extendedWidgetValue = "";

      if (this._extendedWidget) {
        extendedWidgetValue = this._extendedWidget.get("value");
      }

      var selectorValue = this._selector.value;

      if (extendedWidgetValue) {
        this._selector._set("value", selectorValue.split(this._recordFieldSeparator)[0] + this._recordFieldSeparator + extendedWidgetValue);
      } else {
        this._selector._set("value", selectorValue.split(this._recordFieldSeparator)[0]);
      }
    },
    _setExtendedWidgetValueAttr: function _setExtendedWidgetValueAttr(
    /*Object*/
    item) {
      // summary:
      //      override to disable onChange event when setting the value at initialization
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      protected, abstract
      if (!this._extendedWidget || !item) {
        return;
      }

      var extendedWidgetValue = this._getExtendedWidgetValue(item);

      var extendedWidgetControl = this._getExtendedWidgetControl();

      if (extendedWidgetControl) {
        extendedWidgetControl._onChangeActive = false; // disable onChange event

        this._extendedWidget.set("value", extendedWidgetValue);

        extendedWidgetControl._onChangeActive = true; // enable onChange event again
      }
    },
    _getExtendedWidgetControl: function _getExtendedWidgetControl() {
      // summary:
      //      By default, return the control inside the widget
      // tags:
      //      protected, abstract
      return this._extendedWidget;
    },
    _getAllowPreviewableTextBoxItems: function _getAllowPreviewableTextBoxItems() {
      // summary:
      //      get options which should be decorated by an extended widget. By default it a empty array, it means that there isn't any item being decorrated.
      // tags:
      //      protected
      return [];
    },
    _validToAddExtendedWidget: function _validToAddExtendedWidget(
    /*Object*/
    item) {
      // summary:
      //      Verifies that should be to create and then add extended widget or not.
      //      By default, return TRUE.
      //      Can be modified in an extended class.
      // item: [Object]
      //      Item data object used to build extended widget.
      // returns: [Boolean]
      //      TRUE:       Create and then Add extended widget. (Default)
      //      FALSE:      Do nothing.
      // tags:
      //      protected, extensions
      if (!item) {
        return false;
      }

      var allowedTypes = this._getAllowPreviewableTextBoxItems();

      if (!(allowedTypes instanceof Array) || allowedTypes.length <= 0) {
        return false;
      }

      var i = 0,
          totalTypes = allowedTypes.length,
          type = null;

      for (; i < totalTypes; i++) {
        type = allowedTypes[i];

        if (type && item.value.toLowerCase().indexOf(type.toLowerCase()) !== -1) {
          return true;
        }
      }

      return false;
    },
    _doSetupExtendedWidget: function _doSetupExtendedWidget(
    /*Object*/
    item,
    /*Object*/
    extendedWidget) {// summary:
      //      Do the setup for the extendedWidget. By default do nothing
      // tags:
      //      protected
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _setupExtendedWidget: function _setupExtendedWidget(
    /*Object*/
    item) {
      // summary:
      //      Set up the extended widget if needed
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      private
      when(this._getExtendedWidget(), lang.hitch(this, function (extendedWidget) {
        if (!extendedWidget || !item) {
          return;
        }

        this.set("extendedWidgetValue", item);

        this._doSetupExtendedWidget(item, extendedWidget);

        this.own(aspect.before(extendedWidget, "onChange", lang.hitch(this, this._updateSelectorValue)));
      }));
    }
  });
});