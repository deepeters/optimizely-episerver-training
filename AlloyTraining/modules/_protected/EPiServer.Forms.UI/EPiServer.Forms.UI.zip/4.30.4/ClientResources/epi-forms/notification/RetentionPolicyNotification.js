define("epi-forms/notification/RetentionPolicyNotification", [// dojo
"dojo/_base/declare", "dojo/Stateful"], function ( // dojo
declare, Stateful) {
  return declare([Stateful], {
    // summary:
    //      Notification when form has settings for retention policies
    // tags:
    //      internal
    _valueSetter: function _valueSetter(value) {
      // summary:
      //      Show the retention policy notification when opening a form
      // value: Object
      // tags:
      //      private
      if (!value.isModifyingPolicy) {
        return;
      }

      if (value.notificationMessage) {
        this.set("notification", {
          content: value.notificationMessage,
          order: value.order
        });
      } else {
        this.set("notification", {});
      }
    }
  });
});